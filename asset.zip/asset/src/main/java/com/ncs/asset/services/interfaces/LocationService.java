package com.ncs.asset.services.interfaces;

import com.ncs.asset.model.Location;

public interface LocationService {

    Location saveLocation(Location location);
}
