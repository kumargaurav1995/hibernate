package com.ncs.asset.security;

import com.ncs.asset.dto.LoginDto;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import org.springframework.stereotype.Component;

@Component
public class JwtValidator {


    private String secret = "ncsi";

    public LoginDto validate(String token) {

        LoginDto loginDto = null;
        try {
            Claims body = Jwts.parser()
                    .setSigningKey(secret)
                    .parseClaimsJws(token)
                    .getBody();

            loginDto = new LoginDto();

            loginDto.setUserName(body.getSubject());
            loginDto.setPassword((String) body.get("password"));
            loginDto.setRole((String) body.get("role"));
        }
        catch (Exception e) {
            System.out.println(e);
        }

        return loginDto;
    }
}
