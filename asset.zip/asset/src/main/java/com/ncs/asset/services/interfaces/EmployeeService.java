package com.ncs.asset.services.interfaces;

import com.ncs.asset.model.Employee;

public interface EmployeeService {

    Employee saveEmployee(Employee employee);
}
