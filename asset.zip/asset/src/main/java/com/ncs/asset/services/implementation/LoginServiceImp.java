package com.ncs.asset.services.implementation;


import com.ncs.asset.dto.LoginDto;
import com.ncs.asset.repository.UserRepository;
import com.ncs.asset.security.JwtGenerator;
import com.ncs.asset.services.interfaces.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginServiceImp implements LoginService {

    @Autowired
    UserRepository userRepository;

    private JwtGenerator jwtGenerator;

    public LoginServiceImp(JwtGenerator jwtGenerator) {
        this.jwtGenerator = jwtGenerator;
    }


    @Override
    public String loginAdmin(LoginDto loginDto) {
        return jwtGenerator.generate(loginDto);

    }
}
